package com.example.hossam.lord.LoginActivity.Data.Network;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface NetworkApi {

    static String BASE_API_URL = "http://doctory.codesroots.com/Api/";

    @POST("users")
    @FormUrlEncoded
    Call<ResponseBody> userLogin(@Field("username") String username,
                                 @Field("password") String password);



}
