package com.example.hossam.lord.LoginActivity.View;

import android.app.Activity;
import android.arch.lifecycle.Lifecycle;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.*;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.arch.lifecycle.LifecycleOwner;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.example.hossam.lord.LoginActivity.ViewModel.LoginViewModel;
import com.example.hossam.lord.R;
import com.example.hossam.lord.Utils.StringUtils;
import com.example.hossam.lord.databinding.ActivityLoginBinding;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

public class LoginActivity extends AppCompatActivity implements LifecycleOwner {
    private static final String TAG ="LoginActivity" ;
    private LoginViewModel loginViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

              CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("JF-Flat-Regular.ttf")
                .setFontAttrId(R.attr.fontPath)

                .build()
        );


        final ActivityLoginBinding binding  = DataBindingUtil.setContentView(this, R.layout.activity_login);


        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);

binding.btnLogin.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
String username = binding.etUsername.getText().toString();
String password = binding.etPassword.getText().toString();

if ( validate(username , password) == 3 ){
    Log.d(TAG, "onClick() called with: validate =3 [" + username + "]");
    loginViewModel.attemptLogin(username, password).observe(LoginActivity.this, new Observer<String>() {
        @Override
        public void onChanged(@Nullable String s) {
            Log.d(TAG, "onChanged() called with: s = [" + s + "]");
        }
    });
}
else {
    // TODO set error for et and show snackbar
}



    }
});


    }

    private int validate(String username, String password) {
//// might add some other validation

        if (StringUtils.isNullOrEmpty(username)) {
            return 0;
        }else  if (StringUtils.isNullOrEmpty(password)) {
            return 1;
        } if (StringUtils.isNullOrEmpty(username)  && StringUtils.isNullOrEmpty(password) ) {
            return 2;
        }else { return 3;  }

    }

    @NonNull
    @Override
    public Lifecycle getLifecycle() {
        return null;
    }

    /*    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }*/

}
