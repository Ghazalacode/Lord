package com.example.hossam.lord.LoginActivity.Data;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.util.Log;

import com.example.hossam.lord.LoginActivity.Data.Network.NetworkApi;
import com.example.hossam.lord.LoginActivity.Data.Network.RetrofitClient;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Field;

public class LoginRepository {

    public LoginRepository() {
    }

    private NetworkApi networkApiClient  =null ;

    //…
    final MutableLiveData<String> data = new MutableLiveData<>();
    public LiveData<String> userlogin(String username, String password) {




        networkApiClient =  RetrofitClient.getClient(NetworkApi.BASE_API_URL).create(NetworkApi.class);
        networkApiClient.userLogin(username, password).enqueue(new Callback<ResponseBody>() {
             @Override
             public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                   data.postValue(response.body().toString());
                 Log.d("", "onResponse() called with: call = [" + call + "], response = [" + response + "]");
             }

             @Override
             public void onFailure(Call<ResponseBody> call, Throwable t) {
                 Log.d("failure", "onFailure() called with: call = [" + call + "], t = [" + t + "]");
                    data.postValue(t.getMessage());
             }
         }


        );
    if (data == null){data .setValue("76868");
    return data; }
       else { return data;}
    }
}
